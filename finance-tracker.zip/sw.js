/* Service worker: keeps a copy of the app on the phone so it opens without internet.
   Your financial data is NOT here — it lives in the browser's localStorage.
   When you change any file, bump CACHE (e.g. 'financas-v2') so phones pick up the new version. */
const CACHE = 'financas-v1';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './vendor/chart.umd.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-64.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/** Network with a time limit, so a weak signal doesn't leave the app hanging. */
function fetchWithTimeout(request, ms) {
  return Promise.race([
    fetch(request),
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
  ]);
}

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;

  // The page itself: try the network first (to get updates), fall back to the cached copy offline.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetchWithTimeout(req, 3000)
        .then(res => {
          if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put('./index.html', copy)); }
          return res;
        })
        .catch(() => caches.match('./index.html'))
    );
    return;
  }

  // Icons, Chart.js, manifest: cached copy first, network as a fallback.
  event.respondWith(
    caches.match(req).then(hit => hit || fetch(req).then(res => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
      return res;
    }))
  );
});
