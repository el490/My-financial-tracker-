#!/usr/bin/env node
/* Runs the commission split test cases defined inside index.html.
   Usage: node test-split.js */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const match = html.match(/<script id="core">([\s\S]*?)<\/script>/);
if (!match) { console.error('Could not find <script id="core"> in index.html'); process.exit(1); }

const ctx = vm.createContext({});
vm.runInContext(match[1], ctx);

const results = ctx.runSplitTests();
for (const r of results) {
  console.log(`${r.pass ? 'PASS' : 'FAIL'}  ${r.name}`);
  console.log('      ' + Object.entries(r.pots).map(([k, v]) => `${k}=${ctx.fmtBRL(v)}`).join('  '));
  for (const w of r.warnings) console.log(`      warning: ${w}`);
  for (const p of r.problems) console.log(`      problem: ${p}`);
}
const failed = results.filter(r => !r.pass).length;
console.log(`\n${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);
